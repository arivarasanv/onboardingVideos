export const environment = {
    production: true,
    backendUrl: 'https://api.bawagpsk.com/craftsmen/gw/bfl'
};
