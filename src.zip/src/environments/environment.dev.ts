export const environment = {
    production: false,
    backendUrl: 'https://api.tst.bawagpsk.com/craftsmen/gw/bfl'
};
