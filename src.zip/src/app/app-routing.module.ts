import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PartnerServiceRequestComponent } from "./partner-service-request/partner-service-request.component";
import { CustomerServiceRequestComponent } from './customer-service-request/customer-service-request.component';
import { GeneralServiceRequestComponent } from "./general-service-request/general-service-request.component";
import { PartnerClarificationRequestComponent } from './partner-clarification-request/partner-clarification-request.component';
import { LandingComponent } from './landing/landing.component';
import { PartialPayoutComponent } from './partial-payout-request/partial-payout.component';
import { SepaServiceRequestComponent } from './sepa-service-request/sepa-service-request.component';


import {DeferralRequestComponent} from "./deferral-request/deferral-request.component";

const routes: Routes = [
    {path: 'psr', component: PartnerServiceRequestComponent, data: { title: 'Partner-Serviceantrag' }},
    {path: 'gsr', component: GeneralServiceRequestComponent, data: { title: 'Ihr Anliegen ist uns wichtig!' }},
    {path: 'pcr', component: PartnerClarificationRequestComponent, data: { title: 'Klärung der offenen Posten' }},
    {path: 'csr', component: CustomerServiceRequestComponent, data: { title: 'Kunden: Klärung offene Posten' }},
    {path: 'dr', component: DeferralRequestComponent, data: { title: 'Antrag auf Stundung' }},
    {path: 'ps', component: PartialPayoutComponent, data: {title: 'Antrag auf Teilablöse'}},
    {path: 'sepa', component: SepaServiceRequestComponent, data: {title: 'Einreichung von Vertragsunterlagen'}},
    {path: '', pathMatch: 'full', component: LandingComponent},
];

@NgModule({
    imports: [RouterModule.forRoot(routes)], exports: [RouterModule]
})
export class AppRoutingModule {
}
