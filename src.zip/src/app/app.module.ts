import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClarityModule } from '@clr/angular';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { DropzoneComponent } from './components/dropzone/dropzone.component';
import { HeaderComponent } from './components/header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FooterComponent } from './components/footer/footer.component';

import { PartnerServiceRequestComponent } from './partner-service-request/partner-service-request.component';
import { PartnerServiceRequestStepYourDataComponent } from './partner-service-request/partner-service-request-step-your-data/partner-service-request-step-your-data.component';
import { PartnerServiceRequestStepYourRequestComponent } from './partner-service-request/partner-service-request-step-your-request/partner-service-request-step-your-request.component';

import { MatNativeDateModule, MAT_DATE_LOCALE } from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';

import { CustomDropzonePreviewComponent } from './components/dropzone/custom-dropzone-preview/custom-dropzone-preview.component';
import { CustomerServiceRequestComponent } from './customer-service-request/customer-service-request.component';
import { CustomerServiceRequestStepYourDataComponent } from './customer-service-request/customer-service-request-step-your-data/customer-service-request-step-your-data.component';
import { CustomerServiceRequestStepYourRequestComponent } from './customer-service-request/customer-service-request-step-your-request/customer-service-request-step-your-request.component';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import {
  GeneralServiceRequestStepYourDataComponent
} from "./general-service-request/general-service-request-step-your-data/general-service-request-step-your-data.component";
import {
  GeneralServiceRequestStepYourRequestComponent
} from "./general-service-request/general-service-request-step-your-request/general-service-request-step-your-request.component";
import {GeneralServiceRequestComponent} from "./general-service-request/general-service-request.component";
import { PartnerClarificationRequestComponent } from './partner-clarification-request/partner-clarification-request.component';
import { PartnerClarificationRequestStepYourDataComponent } from './partner-clarification-request/partner-clarification-request-step-your-data/partner-clarification-request-step-your-data.component';
import { PartnerClarificationRequestStepYourRequestComponent } from './partner-clarification-request/partner-clarification-request-step-your-request/partner-clarification-request-step-your-request.component';
import {DeferralRequestComponent} from "./deferral-request/deferral-request.component";
import {
  DeferralRequestStepYourDataComponent
} from "./deferral-request/deferral-request-step-your-data/deferral-request-step-your-data.component";
import {
  DeferralRequestStepYourRequestComponent
} from "./deferral-request/deferral-request-step-your-request/deferral-request-step-your-request.component";
import { LandingComponent } from './landing/landing.component';
import { DatePickerComponent } from './components/date-picker/date-picker.component';
import { TimePickerComponent } from './components/time-picker/time-picker.component';
import { MatInputModule } from '@angular/material/input';
import { PartialPayoutComponent } from './partial-payout-request/partial-payout.component';
import { PartialPayoutStepYourDataComponent } from './partial-payout-request/partial-payout-step-your-data/partial-payout-step-your-data.component';
import { PartialPayoutStepYourRequestComponent } from './partial-payout-request/partial-payout-step-your-request/partial-payout-step-your-request.component';
import { SepaServiceRequestComponent } from './sepa-service-request/sepa-service-request.component';
import { SepaServiceRequestStepYourDataComponent } from './sepa-service-request/sepa-service-request-step-your-data/sepa-service-request-step-your-data.component';
import { SepaServiceRequestStepYourRequestComponent } from './sepa-service-request/sepa-service-request-step-your-request/sepa-service-request-step-your-request.component';



@NgModule({
  declarations: [
    AppComponent,
    PartnerServiceRequestComponent,
    PartnerServiceRequestStepYourDataComponent,
    PartnerServiceRequestStepYourRequestComponent,
    GeneralServiceRequestComponent,
    GeneralServiceRequestStepYourDataComponent,
    GeneralServiceRequestStepYourRequestComponent,
    DropzoneComponent,
    HeaderComponent,
    FooterComponent,
    CustomDropzonePreviewComponent,
    CustomerServiceRequestComponent,
    CustomerServiceRequestStepYourDataComponent,
    CustomerServiceRequestStepYourRequestComponent,
    PartnerClarificationRequestComponent,
    PartnerClarificationRequestStepYourDataComponent,
    PartnerClarificationRequestStepYourRequestComponent,
    CustomerServiceRequestStepYourRequestComponent,
    DeferralRequestComponent,
    DeferralRequestStepYourDataComponent,
    DeferralRequestStepYourRequestComponent,
    LandingComponent,
    DatePickerComponent,
    TimePickerComponent,
    PartialPayoutComponent,
    PartialPayoutStepYourDataComponent,
    PartialPayoutStepYourRequestComponent,
    SepaServiceRequestComponent,
    SepaServiceRequestStepYourDataComponent,
    SepaServiceRequestStepYourRequestComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ClarityModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxDropzoneModule,
    BrowserAnimationsModule,
    MatNativeDateModule,
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    NgxMatTimepickerModule
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'de' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
