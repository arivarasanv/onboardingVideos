import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';

@Component({
    selector: 'app-header', templateUrl: './header.component.html', styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    homeUrl: string = "https://www.bfl-leasing.de/service/";

    constructor(@Inject(DOCUMENT) private document: Document) {
    }

    ngOnInit(): void {
    }

    navigateToHome() {
        this.document.location.href = this.homeUrl;
    }

}
