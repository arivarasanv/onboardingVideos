import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss']
})
export class DatePickerComponent implements OnInit {

  @Input() isInvalid: boolean | undefined;
  @Output() dateSelectedEvent = new EventEmitter<string>();
  @Output() inputClickedEvent = new EventEmitter<boolean>();
  public minDate: Date = new Date(Date.now());
  public dateValue: string;

  constructor() { }

  ngOnInit(): void {
    
  }

  emitValue(inputValue: string) {
    this.dateSelectedEvent.emit(inputValue);
  }

  ngDoCheck() {
    //TOINVESTIGATE:change detection runs 4 times here. Why?
    this.emitValue(this.dateValue);
  }


  emitInputClickedEvent() {
    this.inputClickedEvent.emit(true);
  }
}
