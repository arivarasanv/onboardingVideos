import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { HelperFunctions } from 'src/app/helpers/helper-functions';
import { DropzoneDocumentStorageService } from 'src/app/services/dropzone-document-storage.service';


@Component({
  selector: 'app-dropzone',
  templateUrl: './dropzone.component.html',
  styleUrls: ['./dropzone.component.scss']
})

export class DropzoneComponent implements OnInit {
  @Output() addDocumentEvent = new EventEmitter<string>();
  @Output() removeDocumentEvent = new EventEmitter<string>();
  @Output() unsupportedTypesEvent = new EventEmitter<string[][]>();
  @Output() fileCountMaximumReachedEvent = new EventEmitter<boolean>();
  @Output() fileCountMinimumNotReachedEvent = new EventEmitter<boolean>();
  @Output() documentsNotUploadedEvent = new EventEmitter<boolean>();

  @Input() minimumFileCount: number;
  @Input() maximumFileCount: number;
  @Input() guid: string;

  files: File[] = [];
  supportedExtensions: string[] = [
    "pdf",
    " png",
    " jpg/jpeg",
    " docx",
    " odt"
  ]

  constructor(private http: HttpClient, private dropzoneDocumentStorageService: DropzoneDocumentStorageService) {
  }

  ngOnInit(): void {
    this.files = this.dropzoneDocumentStorageService.getFiles();
  }

  //TODO: rename to onFileDrop
  //TODO: either move the child functions into component methods or helper functions(preferably helper funcs)
  onSelect(event: any) {
    if (this.files.length == this.maximumFileCount) {
      this.fileCountMaximumReachedEvent.emit(true);
      this.fileCountMinimumNotReachedEvent.emit(false);
    } 
    else if((event.addedFiles.length + this.files.length) > this.maximumFileCount) {
      this.fileCountMaximumReachedEvent.emit(true);
      this.fileCountMinimumNotReachedEvent.emit(false);
    }     
    else {
      let files = this.files;

      if (event.rejectedFiles.length > 0) {
        let unsupportedTypes: string[][] = [[], this.supportedExtensions];
        for (let i = 0; i < event.rejectedFiles.length; i++) {
          unsupportedTypes[0].push((unsupportedTypes[0].length > 0) ? " " + event.rejectedFiles[i].name : event.rejectedFiles[i].name);
        }

        this.unsupportedTypesEvent.emit(unsupportedTypes);
      }

      for (let i = 0; i < event.addedFiles.length; i++)
        checkForDuplicates(i);

      this.dropzoneDocumentStorageService.addFiles(event.addedFiles);
      if(this.files.length != this.minimumFileCount){
        this.fileCountMinimumNotReachedEvent.emit(true);
        this.fileCountMaximumReachedEvent.emit(false);
      }

      let url = `${environment.backendUrl}`
      const formData = new FormData();
      for (let i = 0; i < event.addedFiles.length; i++) {
        formData.append("fileUpload", event.addedFiles[i]);
        let fileName = event.addedFiles[i].name;
        this.uploadDocument(url, this.guid, formData, fileName);
      }

      if(this.files.length >= this.minimumFileCount && this.files.length <= this.maximumFileCount){
        this.fileCountMinimumNotReachedEvent.emit(false);
        this.fileCountMaximumReachedEvent.emit(false);
      }

      function checkForDuplicates(i: number) {
        files.forEach((element) => {
          if (event.addedFiles[i].name == element.name)
            giveUniqueName(i);
        });
      }

      function giveUniqueName(i: number) {
        let fullFileName = event.addedFiles[i].name;
        let fileName = fullFileName.split(".")[0];
        let fileExtension = fullFileName.split(".")[1];
        Object.defineProperty(event.addedFiles[i], 'name', {
          writable: true,
          value: fileName + Date.now() + '.' + fileExtension
        });
      }
    }
  }

  private uploadDocument(url: string, guid: string, formData: FormData, fileName: string) {
    this.http.post(url + '/document/' + guid, formData)
      .subscribe(
        {
          next: (res: any) => {
            //TODO: make this more type safe
            let documentId = res.documentId;
            this.dropzoneDocumentStorageService.addDocument(fileName, documentId);
            this.addDocumentEvent.emit(documentId);
            this.documentsNotUploadedEvent.emit(false);
            this.files = this.dropzoneDocumentStorageService.getFiles();
          },
          error: () => {
            this.documentsNotUploadedEvent.emit(true);
            this.dropzoneDocumentStorageService.clearFiles();
            this.files = [];
          }
        })
  }

  onRemove(event: any) {
    let url = `${environment.backendUrl}`
    let documentId = this.dropzoneDocumentStorageService.getDocumentId(event.name);
    //TODO: make response checks(if 200 then notify&delete preview, if 400/500 handle accordingly)
    this.http.delete(url + '/document/' + documentId).subscribe(
      {
        next: () => {
          this.dropzoneDocumentStorageService.removeDocument(documentId);
          this.removeDocumentEvent.emit(documentId);
          this.files.splice(this.files.indexOf(event), 1);
          this.removeDocumentEvent.emit(documentId);
          if(this.files.length <= this.maximumFileCount && this.files.length >= this.minimumFileCount){
            this.fileCountMaximumReachedEvent.emit(false);
            this.fileCountMinimumNotReachedEvent.emit(false);
          }
          else if(this.files.length < this.minimumFileCount){
            this.fileCountMinimumNotReachedEvent.emit(true);
            this.fileCountMaximumReachedEvent.emit(false);
          }
        },
        error: () => {
          alert('Unable to delete document');
        }
      }
    )
  }
}

