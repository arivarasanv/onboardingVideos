export interface BflDocument {
    name: string,
    documentId: string
}