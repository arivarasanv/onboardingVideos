import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-time-picker',
  templateUrl: './time-picker.component.html',
  styleUrls: ['./time-picker.component.scss']
})
export class TimePickerComponent implements OnInit {

  @Input() isInvalid: boolean | undefined;
  @Output() timeSelectedEvent = new EventEmitter<string>();
  public timeValue: string;

  constructor() { }

  ngOnInit(): void {
  }

  emitValue(inputValue: string) {
    this.timeSelectedEvent.emit(inputValue);
  }

  ngDoCheck() {
    //TOINVESTIGATE:change detection runs 4 times here. Why? timepicker emits even more than date it seems
    this.emitValue(this.timeValue);
  }

}
