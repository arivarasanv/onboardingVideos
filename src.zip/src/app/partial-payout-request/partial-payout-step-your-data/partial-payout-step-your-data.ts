export interface PartialPayoutStepYourData {
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    bflNumber: string | null,
    distributor: string,
}