export interface PartialPayoutPayload {
    formType: string,
    email: string,
    phone: string,
    documents: string[],
    requestDescription: string,
    firstName: string,
    lastName: string,
    bflNumber: string | null,
    timeOfDetachment: string | null,
    maintenanceNew: boolean,
    distributor: string
}
