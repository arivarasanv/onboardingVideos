import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HelperFunctions } from '../helpers/helper-functions';
import { DropzoneDocumentStorageService } from '../services/dropzone-document-storage.service';
import { ServiceRequestService } from '../services/service-request.service';
import { PartialPayoutStepYourDataComponent } from './partial-payout-step-your-data/partial-payout-step-your-data.component';
import { PartialPayoutStepYourRequestComponent } from './partial-payout-step-your-request/partial-payout-step-your-request.component';
import { PartialPayoutPayload } from './partial-payout';

@Component({
  selector: 'app-partial-payout',
  templateUrl: './partial-payout.component.html',
  styleUrls: ['./partial-payout.component.scss']
})
export class PartialPayoutComponent implements OnInit {
  @ViewChild(PartialPayoutStepYourDataComponent, {static: true}) stepYourDataGroup: PartialPayoutStepYourDataComponent;
  @ViewChild(PartialPayoutStepYourRequestComponent, {static: true}) stepYourRequestGroup: PartialPayoutStepYourRequestComponent;

    partialSolution: FormGroup;
    stepYourData: FormGroup;
    stepYourRequest: FormGroup;
    firstPage: boolean = true;
    secondPage: boolean;
    isAppFinishedPopup = false;
    submitFailed: boolean;
    sendButtonClicked: boolean;
    requestGuid: string;

  constructor( private fb: FormBuilder,
    private serviceRequestService: ServiceRequestService,
    private dropzoneDocumentStorageService: DropzoneDocumentStorageService) {
    this.firstPage = true;
     }

  ngOnInit(): void {
    this.stepYourData = this.fb.group(this.stepYourDataGroup.getConfig());
    this.stepYourRequest = this.fb.group(this.stepYourRequestGroup.getConfig());

    this.partialSolution = this.fb.group({
      stepYourData: this.stepYourData,
      stepYourRequest: this.stepYourRequest
    })

    this.dropzoneDocumentStorageService.files = [];

    this.requestGuid = HelperFunctions.generateUUIDUsingMathRandom();
  }

  switchPages() {
    if (this.firstPage) {
      this.stepYourData.markAllAsTouched();
      if (this.stepYourData.invalid) {
        return;
      }
    }
    this.firstPage = !this.firstPage;
    this.secondPage = !this.secondPage;
  }

  submitRequest() {
    this.sendButtonClicked = true;
    if (this.secondPage) {
      this.stepYourRequest.markAllAsTouched();
      if (this.stepYourRequest.invalid) {
        this.sendButtonClicked = false;
        return;
      }
    }

    let stepYourData = this.partialSolution.value.stepYourData;
    let stepYourRequest = this.partialSolution.value.stepYourRequest;
    let combined = Object.assign(stepYourData, stepYourRequest);

    let payload: PartialPayoutPayload = {
      formType: "PARTIAL_PAYOUT_REQUEST",
      email: combined.email,
      phone: combined.phone,
      documents: combined.documents,
      requestDescription: combined.requestDescription,
      firstName: combined.firstName,
      lastName: combined.lastName,
      bflNumber: null,
      timeOfDetachment: combined.timeOfDetachment,
      maintenanceNew: combined.maintenanceNew,
      distributor: combined.distributor

    }

    payload.timeOfDetachment = formatDate();

    if(combined.bflNumber != undefined && combined.bflNumber != ""){
      payload.bflNumber = combined.bflNumber;
    }

    if(stepYourRequest.documents != null)
      payload.documents = stepYourRequest.documents;


    this.serviceRequestService.submitRequest(payload, this.requestGuid).subscribe(
      {
        next: () => {this.submitFailed = false; this.isAppFinishedPopup = true;},
        error: () => {this.submitFailed = true; this.sendButtonClicked = false;}
        
      });


    //TODO: solve this via DatePipe
    function formatDate() {
      function addLeadingZeros(n: any) {
        if (n <= 9) {
          return "0" + n;
        }
        return n;
      }

      let currentDatetime = new Date(combined.timeOfDetachment);

      return currentDatetime.getFullYear() + "-" +
        addLeadingZeros(currentDatetime.getMonth() + 1) +
        "-" + addLeadingZeros(currentDatetime.getDate());
    }
    
  }

  onFinishPopupClose() {
    HelperFunctions.redirectToExternalHomeUrl();
  }

}


