import { Component, Input,  OnInit } from '@angular/core';
import { FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { FormGroupConfig } from 'src/app/helpers/form-group-config';
import { PartialPayoutStepYourRequest } from './partial-payout-step-your-request'

@Component({
  selector: 'app-partial-payout-step-your-request',
  templateUrl: './partial-payout-step-your-request.component.html',
  styleUrls: ['./partial-payout-step-your-request.component.scss']
})
export class PartialPayoutStepYourRequestComponent implements OnInit {
  public _parent: FormGroup;
  @Input() displayQuestions: boolean;
  @Input() guid: string;

  public unsupportedFiles: string[];
  public supportedFileExtensions: string[];

  public MINIMUM_DROPZONE_FILE_COUNT: number = 1;
  public MAXIMUM_DROPZONE_FILE_COUNT: number = 5;

  public maxFileCountReached: boolean;
  public minFileCountNotReached: boolean;

  public documentsNotUploaded: boolean;
  

  constructor(private rootFormGroup: FormGroupDirective) { }

  ngOnInit(): void {
    this._parent = this.rootFormGroup.control;
    this._parent.valueChanges.subscribe(() => {
      if(this._parent.controls.stepYourRequest.value.documents.length <= 0)
        this._parent.controls.stepYourRequest.get('documents')?.setErrors({'incorrect': true});
      else
        this._parent.controls.stepYourRequest.get('documents')?.setErrors(null);
    })
  }

  getConfig() {
    const config: FormGroupConfig<PartialPayoutStepYourRequest> = {
      requestDescription: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(250)]],
      documents: [[], [Validators.minLength(1), Validators.maxLength(5)]],
      timeOfDetachment: ['', []],
      maintenanceNew: [false, [Validators.required]],
    }

    return config;
  }

  handleDatePickerInputClicked(inputClicked: boolean) {
    if(inputClicked){
      this._parent.get('stepYourRequest')!.get("timeOfDetachment")?.markAsTouched();
    }
  }

  handleDocumentsNotUploaded(status: boolean) {
    this.documentsNotUploaded = status; 
  }

  handleFileCountMaximumReached(status: boolean) {
    this.maxFileCountReached = status;
  }
  handleFileCountMinimumNotReached(status: boolean) {
    this.minFileCountNotReached = status;
  }

  updateDropzoneControlState() {
    this._parent.get('stepYourRequest.documents')?.markAsTouched();
  }

  addDocumentIdToRequest(id: string) {
    let arr = this._parent.value.stepYourRequest.documents;
    if(arr != null){
      arr.push(id);
    }
    else{
      arr = []
      arr.push(id);
    }
    this._parent.controls.stepYourRequest.patchValue({"documents": arr})  
  }

  removeDocumentIdFromRequest(id: string) {
    let index = this._parent.value.stepYourRequest.documents.indexOf(id);
    this._parent.value.stepYourRequest.documents.splice(index, 1);
    let arr = this._parent.value.stepYourRequest.documents;
    this._parent.controls.stepYourRequest.patchValue({"documents": arr});
  }

  syncDateWithParent(selectedDate: string){
    this._parent.controls.stepYourRequest.patchValue({"timeOfDetachment": selectedDate});
  }

  documentsRequired() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount < 1;
    }
    return false;
  }

  documentsMax() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount > 1;
    }
    return false;
  }

  fileTypesUnsupported() {
    return this.unsupportedFiles != null;
  }

  handleUnsupportedFileTypes(extensions: string[][]) {
    //TODECIDE: is it wise to emit supported extensions as 2nd dimension of event array?
    this.unsupportedFiles = extensions[0];
    this.supportedFileExtensions = extensions[1];
  }

  fieldInvalid(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.invalid && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
    
  }

  fieldRequired(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.required && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldPattern(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.pattern && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMinLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.minlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMaxLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.maxlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldEmail() {
    return this._parent.get('stepYourRequest.email')!.errors?.email && this._parent.get('stepYourRequest.email')!.touched;
  }


}
