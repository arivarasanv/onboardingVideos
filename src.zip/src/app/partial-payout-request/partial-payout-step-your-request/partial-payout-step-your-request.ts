export interface PartialPayoutStepYourRequest {
    requestDescription: string,
    documents: string[],
    timeOfDetachment: string,
    maintenanceNew: boolean

}