import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { HelperFunctions } from '../helpers/helper-functions';
import { DropzoneDocumentStorageService } from '../services/dropzone-document-storage.service';
import {ServiceRequestService} from '../services/service-request.service';
import {DeferralRequestPayload} from './deferral-request';
import {
  DeferralRequestStepYourDataComponent
} from './deferral-request-step-your-data/deferral-request-step-your-data.component';
import {
  DeferralRequestStepYourRequestComponent
} from './deferral-request-step-your-request/deferral-request-step-your-request.component';

@Component({
  selector: 'app-deferral-request',
  templateUrl: './deferral-request.component.html',
  styleUrls: ['./deferral-request.component.scss']
})
export class DeferralRequestComponent implements OnInit {

  @ViewChild(DeferralRequestStepYourDataComponent, {static: true}) stepYourDataGroup: DeferralRequestStepYourDataComponent;
  @ViewChild(DeferralRequestStepYourRequestComponent, {static: true}) stepYourRequestGroup: DeferralRequestStepYourRequestComponent;


  deferralRequest: FormGroup;
  stepYourData: FormGroup;
  stepYourRequest: FormGroup;
  firstPage: boolean = true;
  secondPage: boolean;
  isAppFinishedPopup = false;
  submitFailed: boolean;
  sendButtonClicked: boolean;
  requestGuid: string;

  constructor(private fb: FormBuilder,
              private serviceRequestService: ServiceRequestService,
              private dropzoneDocumentStorageService: DropzoneDocumentStorageService) {
    this.firstPage = true;
  }

  ngOnInit(): void {
    this.stepYourData = this.fb.group(this.stepYourDataGroup.getConfig());
    this.stepYourRequest = this.fb.group(this.stepYourRequestGroup.getConfig());

    this.deferralRequest = this.fb.group({
      stepYourData: this.stepYourData,
      stepYourRequest: this.stepYourRequest
    })

    this.dropzoneDocumentStorageService.files = [];

    this.requestGuid = HelperFunctions.generateUUIDUsingMathRandom();
  }

  switchPages() {
    if (this.firstPage) {
      this.stepYourData.markAllAsTouched();
      if (this.stepYourData.invalid) {
        return;
      }
    }

    this.firstPage = !this.firstPage;
    this.secondPage = !this.secondPage;
  }

  //TODO: clean this up
  submitRequest() {
    this.sendButtonClicked = true;
    this.stepYourRequest.markAllAsTouched();
    if (this.stepYourRequest.invalid) {
      this.sendButtonClicked = false;
      return;
    }

    let stepYourData = this.deferralRequest.value.stepYourData;
    let stepYourRequest = this.deferralRequest.value.stepYourRequest;
    let combined = Object.assign(stepYourData, stepYourRequest);

    let payload: DeferralRequestPayload = {
      formType: "DEFERRAL_REQUEST",
      email: combined.email,
      phone: combined.phone,
      documents: null,
      requestDescription: combined.requestDescription,
      firstName: combined.firstName,
      lastName: combined.lastName,
      bflNumber: combined.bflNumber,
      customerName: combined.customerName,
    }

    if(stepYourRequest.documents != null)
      payload.documents = stepYourRequest.documents;

    this.serviceRequestService.submitRequest(payload, this.requestGuid).subscribe(
      {
        next: () => {this.submitFailed = false; this.isAppFinishedPopup = true},
        error: () => {this.submitFailed = true; this.sendButtonClicked = false;}
      });
  }

  onFinishPopupClose() {
    HelperFunctions.redirectToExternalHomeUrl();
  }

}
