export interface DeferralRequestStepYourRequest {
    requestDescription: string,
    documents: string[] | null
}
