export interface DeferralRequestStepYourData {
  firstName: string,
  lastName: string,
  email: string,
  phone: string,
  customerName: null | string,
  bflNumber: string
}
