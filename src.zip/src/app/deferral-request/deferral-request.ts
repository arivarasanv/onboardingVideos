export interface DeferralRequestPayload {
  formType: string,
  email: string,
  phone: string,
  documents: string[] | null,
  requestDescription: string,
  firstName: string,
  lastName: string,
  bflNumber: string,
  customerName: string,
}
