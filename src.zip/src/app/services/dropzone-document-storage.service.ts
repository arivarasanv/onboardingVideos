import { Injectable } from "@angular/core";
import { BflDocument } from "../components/dropzone/bfl-document";


@Injectable({
    providedIn: 'root'
})

export class DropzoneDocumentStorageService {

    files: File[] = [];
    documents: BflDocument[] = [];

    constructor(){ }

    addFiles(addedFiles: File[]){
        this.files.push(...addedFiles);
    }

    getFiles() {
        return this.files;
    }

    clearFiles() {
        this.files = [];
    }

    addDocument(name: string, id: string){
        let newDocument: BflDocument = {
            name: name,
            documentId: id
        }
        this.documents.push(newDocument);
    }

    getDocumentId(name: string){
        let documentId;

        for (let index = 0; index < this.documents.length; index++) {
            if(name == this.documents[index].name){
              documentId = this.documents[index].documentId;
              break;
            }
          }

        return documentId;
    }

    //TODO: | undefined was added because http.delete(url + 'endpoint' + documentId) in dropzone component expects string | undefined. Should do it with string only somehow
    removeDocument(id: string | undefined){
        let documentId;

        //TODO: find more efficient way of doing thismaybe just reference by id)
        for (let index = 0; index < this.documents.length; index++) {
            if(id == this.documents[index].documentId){
              documentId = this.documents[index].documentId;
              this.documents.splice(index, 1);
              break;
            }
        }
    }

    getDocuments() {
        return this.documents;
    }
}
