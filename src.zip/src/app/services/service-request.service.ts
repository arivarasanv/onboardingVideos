import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient } from '@angular/common/http';
import { HelperFunctions } from "../helpers/helper-functions";
import {Observable} from "rxjs";

@Injectable({
    providedIn: 'root'
})

export class ServiceRequestService {
    url = `${environment.backendUrl}`;

    constructor(private http: HttpClient){ }

    submitRequest(request: any, guid: string): Observable<Object> {
        return this.http.post(`${this.url}` + '/form/' + guid, request)
    }
}
