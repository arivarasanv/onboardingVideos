import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { HelperFunctions } from '../helpers/helper-functions';
import { DropzoneDocumentStorageService } from '../services/dropzone-document-storage.service';
import {ServiceRequestService} from '../services/service-request.service';
import {SepaServiceRequestComponentPayload} from './sepa-service-request';
import {
  SepaServiceRequestStepYourDataComponent
} from './sepa-service-request-step-your-data/sepa-service-request-step-your-data.component';
import {
  SepaServiceRequestStepYourRequestComponent
} from './sepa-service-request-step-your-request/sepa-service-request-step-your-request.component';

@Component({
  selector: 'app-sepa-service-request',
  templateUrl: './sepa-service-request.component.html',
  styleUrls: ['./sepa-service-request.component.scss']
})
export class SepaServiceRequestComponent implements OnInit {

  @ViewChild(SepaServiceRequestStepYourDataComponent, {static: true}) stepYourDataGroup: SepaServiceRequestStepYourDataComponent;
  @ViewChild(SepaServiceRequestStepYourRequestComponent, {static: true}) stepYourRequestGroup: SepaServiceRequestStepYourRequestComponent;


  sepaServiceRequest: FormGroup;
  stepYourData: FormGroup;
  stepYourRequest: FormGroup;
  firstPage: boolean = true;
  secondPage: boolean;
  isAppFinishedPopup = false;
  submitFailed: boolean;
  sendButtonClicked: boolean;
  requestGuid: string;

  constructor(private fb: FormBuilder,
              private serviceRequestService: ServiceRequestService,
              private dropzoneDocumentStorageService: DropzoneDocumentStorageService) {
    this.firstPage = true;
  }

  ngOnInit(): void {
    this.stepYourData = this.fb.group(this.stepYourDataGroup.getConfig());
    this.stepYourRequest = this.fb.group(this.stepYourRequestGroup.getConfig());

    this.sepaServiceRequest = this.fb.group({
      stepYourData: this.stepYourData,
      stepYourRequest: this.stepYourRequest
    })

    this.dropzoneDocumentStorageService.files = [];

    this.requestGuid = HelperFunctions.generateUUIDUsingMathRandom();
  }

  switchPages() {
    if (this.firstPage) {
      this.stepYourData.markAllAsTouched();
      if (this.stepYourData.invalid) {
        return;
      }
    }

    this.firstPage = !this.firstPage;
    this.secondPage = !this.secondPage;
  }


  //TODO: clean this up
  submitRequest() {
    this.sendButtonClicked = true;
    if (this.secondPage) {
      this.stepYourRequest.markAllAsTouched();
      if (this.stepYourRequest.invalid || this.stepYourRequestGroup.requestTopicsInvalid()) {
        this.sendButtonClicked = false;
        return;
      }
    }

    let stepYourData = this.sepaServiceRequest.value.stepYourData;
    let stepYourRequest = this.sepaServiceRequest.value.stepYourRequest;
    let combined = Object.assign(stepYourData, stepYourRequest);

    let payload: SepaServiceRequestComponentPayload = {
      formType: "SEPA_SERVICE_REQUEST",
      email: combined.email,
      phone: combined.phone,
      documents: null,
      contractActivation: combined.contractActivation,
      firstName: combined.firstName,
      lastName: combined.lastName,
      bflNumber: combined.bflNumber,
      quoteNumber: combined.quoteNumber,
      requestTopics: [],

      //legacyContractNumber: combined.legacyContractNumber,
      //newContractNumber: combined.newContractNumber,
    // desiredCompletionDate: ""
    }

   //payload.desiredCompletionDate = formatDate();

    //  addRequestTopics();

    if(stepYourRequest.documents != null)
      payload.documents = stepYourRequest.documents;


    this.serviceRequestService.submitRequest(payload, this.requestGuid).subscribe(
    {
      next: () => {this.submitFailed = false; this.isAppFinishedPopup = true},
      error: () => {this.submitFailed = true; this.sendButtonClicked = false;}
    });

    // function formatDate() {
    //   function addLeadingZeros(n: any) {
    //     if (n <= 9) {
    //       return "0" + n;
    //     }
    //     return n;
    //   }

    //    let currentDatetime = new Date(combined.desiredCompletionDate);

    //    return currentDatetime.getFullYear() + "-" +
    //      addLeadingZeros(currentDatetime.getMonth() + 1) +
    //      "-" + addLeadingZeros(currentDatetime.getDate());
    // }

    // function addRequestTopics() {
    //   if (stepYourRequest.contractActivation)
    //     payload.requestTopics.push("CONTRACT_ACTIVATION");
    //   if (stepYourRequest.transfer)
    //     payload.requestTopics.push("TRANSFER");
    //   if (stepYourRequest.renewal)
    //     payload.requestTopics.push("RENEWAL");
    //   if (stepYourRequest.termination)
    //     payload.requestTopics.push("TERMINATION");
    //   if (stepYourRequest.partialFee)
    //     payload.requestTopics.push("PARTIAL_FEE");
    //   if (stepYourRequest.masterDataChange)
    //     payload.requestTopics.push("MASTER_DATA_CHANGE");
    //   if (stepYourRequest.requestForCopies)
    //     payload.requestTopics.push("REQUEST_FOR_COPIES");
    //   if (stepYourRequest.servicePriceAdjustment)
    //     payload.requestTopics.push("SERVICE_PRICE_ADJUSTMENT");
    //   if (stepYourRequest.maintenanceMb)
    //     payload.requestTopics.push("MAINTENANCE_MB");
    //   if (stepYourRequest.paymentChange)
    //     payload.requestTopics.push("PAYMENT_CHANGE");
    //   if (stepYourRequest.terminationOfContract)
    //     payload.requestTopics.push("TERMINATION_OF_CONTRACT");
    //   if (stepYourRequest.transferFee)
    //     payload.requestTopics.push("TRANSFER_FEE");
    // }
    // }
  } 

   onFinishPopupClose() {
     HelperFunctions.redirectToExternalHomeUrl();
   }
}
