export interface SepaServiceRequestStepYourData {
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    bflNumber: string,
    quoteNumber: string
}
