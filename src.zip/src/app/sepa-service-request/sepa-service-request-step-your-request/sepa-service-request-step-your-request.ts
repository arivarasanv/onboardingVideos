export interface SepaServiceRequestStepYourRequest {
    contractActivation: boolean,
    id: boolean,
    gwg: boolean,
    acceptanceConfirmation: boolean,
    paymentInstructions: boolean
    documents: string[] | null
}
