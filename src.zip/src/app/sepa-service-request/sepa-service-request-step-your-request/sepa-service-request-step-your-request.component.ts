import { ConditionalExpr } from '@angular/compiler';
import {Component, Input, OnInit, ChangeDetectorRef} from '@angular/core';
import {FormGroup, FormGroupDirective, Validators} from '@angular/forms';
import {FormGroupConfig} from 'src/app/helpers/form-group-config';
import {SepaServiceRequestStepYourRequest} from './sepa-service-request-step-your-request';

@Component({
  selector: 'app-sepa-service-request-step-your-request',
  templateUrl: './sepa-service-request-step-your-request.component.html',
  styleUrls: ['./sepa-service-request-step-your-request.component.scss']
})
export class SepaServiceRequestStepYourRequestComponent implements OnInit {
  //TODO: adopt consistent variable naming style
  public _parent: FormGroup;
  @Input() displayQuestions: boolean;
  @Input() guid: string;

  public unsupportedFiles: string[];
  public supportedFileExtensions: string[];

  public MINIMUM_DROPZONE_FILE_COUNT: number = 0;
  public MAXIMUM_DROPZONE_FILE_COUNT: number = 1;

  public maxFileCountReached: boolean;
  public minFileCountNotReached: boolean;

  public documentsNotUploaded: boolean;

  public clr_position: string = "top-middle";
  private clrPositionWidthBreakpoint: number = 1070;
  isContract:boolean=false;
  
  isSelected: boolean;
  contract:any;
  isDocument: boolean;
  isID: boolean;
  isGwg: boolean;
  isAcceptance: boolean;
  isPayment: boolean;
  isIDDocument: boolean;
  isGwgDocument: boolean;
  isAcceptanceDoc: boolean;
  isPaymentSEPA: boolean;
  isPaymentSEPADoc: boolean;
  isContractDocument: boolean;
  yourmodel:any;
  isContractYes: any;
  isContractNo: any;

  constructor(private rootFormGroup: FormGroupDirective, private changeDetectorRef: ChangeDetectorRef) {
    
  }

  ngOnInit(): void {
    this._parent = this.rootFormGroup.control;
    if(window.innerWidth < this.clrPositionWidthBreakpoint){
      this.clr_position = "top-left"
    }
  }

  
  getConfig() {
    const config: FormGroupConfig<SepaServiceRequestStepYourRequest> = {
      contractActivation: [false, []],
      id: [false, []],
      gwg: [false, []],
      acceptanceConfirmation: [false, []],
      paymentInstructions: [false, []],
      documents: [null, [Validators.maxLength(1)]]
    }

    return config;
  }

  checkRadioButton(e: any,val: any){
    if(val == 'contract'){
      this.isContract = (e.target.value == 'true')
    } else if(val == 'contractDocument'){
      this.isContractDocument = (e.target.value == 'true')
    } else if(val == 'idValue'){
      this.isID = (e.target.value == 'true')
    } else if(val == 'idDocument'){
      this.isIDDocument = (e.target.value == 'true')
    } else if(val == 'gwg'){
      this.isGwg = (e.target.value == 'true')
    } else if(val == 'gwgDocument'){
      this.isGwgDocument = (e.target.value == 'true')
    } else if(val == 'acceptance'){
      this.isAcceptance= (e.target.value == 'true')
    } else if(val == 'acceptanceDoc'){
      this.isAcceptanceDoc= (e.target.value == 'true')
    }else if(val == 'payment'){
        this.isPayment= (e.target.value == 'true')
        this.changeDetectorRef.detectChanges();
    }else if(val == 'paymentSEPA'){
      this.isPaymentSEPA= (e.target.value == 'true')
    }else if(val == 'paymentSEPADocument'){
      this.isPaymentSEPADoc= (e.target.value == 'true')
    }
    }
  //  checkRadioButton(e: any,val: any){
  //   if(val == 'contract')
  //      this.isContract = (e.target.value == 'true');
  //    if(val == 'contractDocument')
  //      this.isContractDocument = (e.target.value == 'true');
  //   if(val == 'id')
  //      this.isID = (e.target.value == 'true');
  //    if(val == 'idDocument')
  //      this.isIDDocument = (e.target.value == 'true');
  //    if(val == 'gwg')
  //      this.isGwg = (e.target.value == 'true');
  //    if(val == 'gwgDocument')
  //      this.isGwgDocument = (e.target.value == 'true');
  //    if(val == 'acceptance')
  //      this.isAcceptance= (e.target.value == 'true');
  //    if(val == 'acceptanceDoc')
  //      this.isAcceptanceDoc= (e.target.value == 'true');
  //    if(val == 'payment')
  //        this.isPayment= (e.target.value == 'true');
  //        // this.changeDetectorRef.detectChanges();
  //    if(val == 'paymentSEPA')
  //      this.isPaymentSEPA= (e.target.value == 'true');
  //    if(val == 'paymentSEPADocument')
  //      this.isPaymentSEPADoc= (e.target.value == 'true');
    
  //    }
  
  
  handleUnsupportedFileTypes(extensions: string[][]) {
    //TODECIDE: is it wise to emit supported extensions as 2nd dimension of event array?
    this.unsupportedFiles = extensions[0];
    this.supportedFileExtensions = extensions[1];
  }

  //TOCHECK: can the change detection be triggered with only splice/push? Is there a way to not use patchValue?
  addDocumentIdToRequest(id: string) {
    let arr = this._parent.value.stepYourRequest.documents;
    if(arr != null){
      arr.push(id);
    }
    else{
      arr = []
      arr.push(id);
    }
    this._parent.controls.stepYourRequest.patchValue({"documents": arr})  
  }

  //TOCHECK: can the change detection be triggered with only splice/push? Is there a way to not use patchValue?
  removeDocumentIdFromRequest(id: string) {
    let index = this._parent.value.stepYourRequest.documents.indexOf(id);
    this._parent.value.stepYourRequest.documents.splice(index, 1);
    let arr = this._parent.value.stepYourRequest.documents;
    this._parent.controls.stepYourRequest.patchValue({"documents": arr});
  }

  documentsMax() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount > 1;
    }
    return false;
  }

  fileTypesUnsupported() {
    return this.unsupportedFiles != null;
  }

  //TODO: find cleaner way to do this check.
  requestTopicsInvalid() {
    if (this._parent.get('stepYourRequest.contract')?.touched ||
      this._parent.get('stepYourRequest.id')?.touched ||
      this._parent.get('stepYourRequest.gwg')?.touched ||
      this._parent.get('stepYourRequest.acceptanceConfirmation')?.touched ||
      this._parent.get('stepYourRequest.paymentInstructions')?.touched) {

      return this._parent.get('stepYourRequest.contractActivation')?.value == false &&
        this._parent.get('stepYourRequest.id')?.value == false &&
        this._parent.get('stepYourRequest.gwg')?.value == false &&
        this._parent.get('stepYourRequest.acceptanceConfirmation')?.value == false &&
        this._parent.get('stepYourRequest.paymentInstructions')?.value == false;
    }
    return false;
  }

  //TODO: add check for touched to improve ux
  // documentsValid() {
  //   if (this._parent.get('stepYourRequest.documents')?.touched) {
  //     let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
  //     if (documentCount < 1) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   }
  //   return false;
  // }

  showWarningSign(fieldname: string){
    return (this.fieldPattern(fieldname)) || (this.fieldMinLength(fieldname) || this.fieldMaxLength(fieldname)) || this.fieldRequired(fieldname);
  }

  handleDatePickerInputClicked(inputClicked: boolean) {
    if(inputClicked)
      this._parent.get('stepYourRequest')!.get("desiredCompletionDate")?.markAsTouched();
  }

  handleFileCountMaximumReached(status: boolean) {
    this.maxFileCountReached = status;
  }
  handleFileCountMinimumNotReached(status: boolean) {
    this.minFileCountNotReached = status;
  }

  handleDocumentsNotUploaded(status: boolean) {
    this.documentsNotUploaded = status;
  }

  //TODO: why is it being triggered twice though?
  updateDropzoneControlState() {
    this._parent.get('stepYourRequest.documents')?.markAsTouched();
  }

  syncDateWithParent(selectedDate: string){
    this._parent.controls.stepYourRequest.patchValue({"desiredCompletionDate": selectedDate});
  }

  fieldInvalid(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.invalid && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldRequired(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.required && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldPattern(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.pattern && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMinLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.minlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMaxLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.maxlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldEmail() {
    return this._parent.get('stepYourRequest.email')!.errors?.email && this._parent.get('stepYourRequest.email')!.touched;
  }
}
