export interface SepaServiceRequestComponentPayload {
    formType: string,
    email: string,
    phone: string,
    documents: string[] | null,
    // requestDescription: combined.requestDescription,
    firstName: string,
    lastName: string,
    bflNumber: string,
    contractActivation: string,
     quoteNumber: string,
     requestTopics: []
}