export interface PartnerServiceRequestStepYourRequest {
    contractActivation: boolean,
    transfer: boolean,
    renewal: boolean,
    termination: boolean,
    partialFee: boolean,
    masterDataChange: boolean,
    requestForCopies: boolean,
    servicePriceAdjustment: boolean,
    maintenanceMb: boolean,
    paymentChange: boolean,
    terminationOfContract: boolean,
    transferFee: boolean,
    legacyContractNumber: null | string,
    newContractNumber: null | string,
    requestDescription: string,
    desiredCompletionDate: string,
    documents: string[] | null
}
