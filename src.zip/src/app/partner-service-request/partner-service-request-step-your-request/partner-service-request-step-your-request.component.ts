import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, FormGroupDirective, Validators} from '@angular/forms';
import {FormGroupConfig} from 'src/app/helpers/form-group-config';
import {PartnerServiceRequestStepYourRequest} from './partner-service-request-step-your-request';

@Component({
  selector: 'app-partner-service-request-step-your-request',
  templateUrl: './partner-service-request-step-your-request.component.html',
  styleUrls: ['./partner-service-request-step-your-request.component.scss']
})
export class PartnerServiceRequestStepYourRequestComponent implements OnInit {
  //TODO: adopt consistent variable naming style
  public _parent: FormGroup;
  @Input() displayQuestions: boolean;
  @Input() guid: string;

  public unsupportedFiles: string[];
  public supportedFileExtensions: string[];

  public MINIMUM_DROPZONE_FILE_COUNT: number = 0;
  public MAXIMUM_DROPZONE_FILE_COUNT: number = 1;

  public maxFileCountReached: boolean;
  public minFileCountNotReached: boolean;

  public documentsNotUploaded: boolean;

  public clr_position: string = "top-middle";
  private clrPositionWidthBreakpoint: number = 1070

  constructor(private rootFormGroup: FormGroupDirective) {

  }

  ngOnInit(): void {
    this._parent = this.rootFormGroup.control;
    if(window.innerWidth < this.clrPositionWidthBreakpoint){
      this.clr_position = "top-left"
    }
  }

  
  getConfig() {
    const config: FormGroupConfig<PartnerServiceRequestStepYourRequest> = {
      contractActivation: [false, []],
      transfer: [false, []],
      renewal: [false, []],
      termination: [false, []],
      partialFee: [false, []],
      masterDataChange: [false, []],
      requestForCopies: [false, []],
      servicePriceAdjustment: [false, []],
      maintenanceMb: [false, []],
      paymentChange: [false, []],
      terminationOfContract: [false, []],
      transferFee: [false, []],
      legacyContractNumber: [null, [Validators.minLength(2), Validators.maxLength(50)]],
      newContractNumber: [null, [Validators.minLength(2), Validators.maxLength(50)]],
      requestDescription: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(250)]],
      desiredCompletionDate: ['', [Validators.required]],
      documents: [null, [Validators.maxLength(1)]]
    }

    return config;
  }

  handleUnsupportedFileTypes(extensions: string[][]) {
    //TODECIDE: is it wise to emit supported extensions as 2nd dimension of event array?
    this.unsupportedFiles = extensions[0];
    this.supportedFileExtensions = extensions[1];
  }

  //TOCHECK: can the change detection be triggered with only splice/push? Is there a way to not use patchValue?
  addDocumentIdToRequest(id: string) {
    let arr = this._parent.value.stepYourRequest.documents;
    if(arr != null){
      arr.push(id);
    }
    else{
      arr = []
      arr.push(id);
    }
    this._parent.controls.stepYourRequest.patchValue({"documents": arr})  
  }

  //TOCHECK: can the change detection be triggered with only splice/push? Is there a way to not use patchValue?
  removeDocumentIdFromRequest(id: string) {
    let index = this._parent.value.stepYourRequest.documents.indexOf(id);
    this._parent.value.stepYourRequest.documents.splice(index, 1);
    let arr = this._parent.value.stepYourRequest.documents;
    this._parent.controls.stepYourRequest.patchValue({"documents": arr});
  }

  documentsMax() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount > 1;
    }
    return false;
  }

  fileTypesUnsupported() {
    return this.unsupportedFiles != null;
  }

  //TODO: find cleaner way to do this check.
  requestTopicsInvalid() {
    if (this._parent.get('stepYourRequest.contractActivation')?.touched ||
      this._parent.get('stepYourRequest.transfer')?.touched ||
      this._parent.get('stepYourRequest.renewal')?.touched ||
      this._parent.get('stepYourRequest.termination')?.touched ||
      this._parent.get('stepYourRequest.partialFee')?.touched ||
      this._parent.get('stepYourRequest.masterDataChange')?.touched ||
      this._parent.get('stepYourRequest.requestForCopies')?.touched ||
      this._parent.get('stepYourRequest.servicePriceAdjustment')?.touched ||
      this._parent.get('stepYourRequest.maintenanceMb')?.touched ||
      this._parent.get('stepYourRequest.paymentChange')?.touched ||
      this._parent.get('stepYourRequest.terminationOfContract')?.touched ||
      this._parent.get('stepYourRequest.transferFee')?.touched) {

      return this._parent.get('stepYourRequest.contractActivation')?.value == false &&
        this._parent.get('stepYourRequest.transfer')?.value == false &&
        this._parent.get('stepYourRequest.renewal')?.value == false &&
        this._parent.get('stepYourRequest.termination')?.value == false &&
        this._parent.get('stepYourRequest.partialFee')?.value == false &&
        this._parent.get('stepYourRequest.masterDataChange')?.value == false &&
        this._parent.get('stepYourRequest.requestForCopies')?.value == false &&
        this._parent.get('stepYourRequest.servicePriceAdjustment')?.value == false &&
        this._parent.get('stepYourRequest.maintenanceMb')?.value == false &&
        this._parent.get('stepYourRequest.paymentChange')?.value == false &&
        this._parent.get('stepYourRequest.terminationOfContract')?.value == false &&
        this._parent.get('stepYourRequest.transferFee')?.value == false;
    }
    return false;
  }

  //TODO: add check for touched to improve ux
  // documentsValid() {
  //   if (this._parent.get('stepYourRequest.documents')?.touched) {
  //     let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
  //     if (documentCount < 1) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   }
  //   return false;
  // }

  showWarningSign(fieldname: string){
    return (this.fieldPattern(fieldname)) || (this.fieldMinLength(fieldname) || this.fieldMaxLength(fieldname)) || this.fieldRequired(fieldname);
  }

  handleDatePickerInputClicked(inputClicked: boolean) {
    if(inputClicked)
      this._parent.get('stepYourRequest')!.get("desiredCompletionDate")?.markAsTouched();
  }

  handleFileCountMaximumReached(status: boolean) {
    this.maxFileCountReached = status;
  }
  handleFileCountMinimumNotReached(status: boolean) {
    this.minFileCountNotReached = status;
  }

  handleDocumentsNotUploaded(status: boolean) {
    this.documentsNotUploaded = status;
  }

  //TODO: why is it being triggered twice though?
  updateDropzoneControlState() {
    this._parent.get('stepYourRequest.documents')?.markAsTouched();
  }

  syncDateWithParent(selectedDate: string){
    this._parent.controls.stepYourRequest.patchValue({"desiredCompletionDate": selectedDate});
  }

  fieldInvalid(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.invalid && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldRequired(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.required && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldPattern(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.pattern && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMinLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.minlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMaxLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.maxlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldEmail() {
    return this._parent.get('stepYourRequest.email')!.errors?.email && this._parent.get('stepYourRequest.email')!.touched;
  }
}
