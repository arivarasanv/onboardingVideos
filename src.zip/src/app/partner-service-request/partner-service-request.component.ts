import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { HelperFunctions } from '../helpers/helper-functions';
import { DropzoneDocumentStorageService } from '../services/dropzone-document-storage.service';
import {ServiceRequestService} from '../services/service-request.service';
import {PartnerServiceRequestPayload} from './partner-service-request';
import {
  PartnerServiceRequestStepYourDataComponent
} from './partner-service-request-step-your-data/partner-service-request-step-your-data.component';
import {
  PartnerServiceRequestStepYourRequestComponent
} from './partner-service-request-step-your-request/partner-service-request-step-your-request.component';

@Component({
  selector: 'app-partner-service-request',
  templateUrl: './partner-service-request.component.html',
  styleUrls: ['./partner-service-request.component.scss']
})
export class PartnerServiceRequestComponent implements OnInit {

  @ViewChild(PartnerServiceRequestStepYourDataComponent, {static: true}) stepYourDataGroup: PartnerServiceRequestStepYourDataComponent;
  @ViewChild(PartnerServiceRequestStepYourRequestComponent, {static: true}) stepYourRequestGroup: PartnerServiceRequestStepYourRequestComponent;


  partnerServiceRequest: FormGroup;
  stepYourData: FormGroup;
  stepYourRequest: FormGroup;
  firstPage: boolean = true;
  secondPage: boolean;
  isAppFinishedPopup = false;
  submitFailed: boolean;
  sendButtonClicked: boolean;
  requestGuid: string;

  constructor(private fb: FormBuilder,
              private serviceRequestService: ServiceRequestService,
              private dropzoneDocumentStorageService: DropzoneDocumentStorageService) {
    this.firstPage = true;
  }

  ngOnInit(): void {
    this.stepYourData = this.fb.group(this.stepYourDataGroup.getConfig());
    this.stepYourRequest = this.fb.group(this.stepYourRequestGroup.getConfig());

    this.partnerServiceRequest = this.fb.group({
      stepYourData: this.stepYourData,
      stepYourRequest: this.stepYourRequest
    })

    this.dropzoneDocumentStorageService.files = [];

    this.requestGuid = HelperFunctions.generateUUIDUsingMathRandom();
  }

  switchPages() {
    if (this.firstPage) {
      this.stepYourData.markAllAsTouched();
      if (this.stepYourData.invalid) {
        return;
      }
    }

    this.firstPage = !this.firstPage;
    this.secondPage = !this.secondPage;
  }


  //TODO: clean this up
  submitRequest() {
    this.sendButtonClicked = true;
    if (this.secondPage) {
      this.stepYourRequest.markAllAsTouched();
      if (this.stepYourRequest.invalid || this.stepYourRequestGroup.requestTopicsInvalid()) {
        this.sendButtonClicked = false;
        return;
      }
    }

    let stepYourData = this.partnerServiceRequest.value.stepYourData;
    let stepYourRequest = this.partnerServiceRequest.value.stepYourRequest;
    let combined = Object.assign(stepYourData, stepYourRequest);

    let payload: PartnerServiceRequestPayload = {
      formType: "PARTNER_SERVICE_REQUEST",
      email: combined.email,
      phone: combined.phone,
      documents: null,
      requestDescription: combined.requestDescription,
      firstName: combined.firstName,
      lastName: combined.lastName,
      bflNumber: combined.bflNumber,
      partnerCompany: combined.partnerCompany,
      requestTopics: [],
      legacyContractNumber: combined.legacyContractNumber,
      newContractNumber: combined.newContractNumber,
      desiredCompletionDate: ""
    }

    payload.desiredCompletionDate = formatDate();

    addRequestTopics();

    if(stepYourRequest.documents != null)
      payload.documents = stepYourRequest.documents;


    this.serviceRequestService.submitRequest(payload, this.requestGuid).subscribe(
    {
      next: () => {this.submitFailed = false; this.isAppFinishedPopup = true},
      error: () => {this.submitFailed = true; this.sendButtonClicked = false;}
    });

    function formatDate() {
      function addLeadingZeros(n: any) {
        if (n <= 9) {
          return "0" + n;
        }
        return n;
      }

      let currentDatetime = new Date(combined.desiredCompletionDate);

      return currentDatetime.getFullYear() + "-" +
        addLeadingZeros(currentDatetime.getMonth() + 1) +
        "-" + addLeadingZeros(currentDatetime.getDate());
    }

    function addRequestTopics() {
      if (stepYourRequest.contractActivation)
        payload.requestTopics.push("CONTRACT_ACTIVATION");
      if (stepYourRequest.transfer)
        payload.requestTopics.push("TRANSFER");
      if (stepYourRequest.renewal)
        payload.requestTopics.push("RENEWAL");
      if (stepYourRequest.termination)
        payload.requestTopics.push("TERMINATION");
      if (stepYourRequest.partialFee)
        payload.requestTopics.push("PARTIAL_FEE");
      if (stepYourRequest.masterDataChange)
        payload.requestTopics.push("MASTER_DATA_CHANGE");
      if (stepYourRequest.requestForCopies)
        payload.requestTopics.push("REQUEST_FOR_COPIES");
      if (stepYourRequest.servicePriceAdjustment)
        payload.requestTopics.push("SERVICE_PRICE_ADJUSTMENT");
      if (stepYourRequest.maintenanceMb)
        payload.requestTopics.push("MAINTENANCE_MB");
      if (stepYourRequest.paymentChange)
        payload.requestTopics.push("PAYMENT_CHANGE");
      if (stepYourRequest.terminationOfContract)
        payload.requestTopics.push("TERMINATION_OF_CONTRACT");
      if (stepYourRequest.transferFee)
        payload.requestTopics.push("TRANSFER_FEE");
    }

  }

  onFinishPopupClose() {
    HelperFunctions.redirectToExternalHomeUrl();
  }
}
