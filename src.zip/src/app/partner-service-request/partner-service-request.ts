export interface PartnerServiceRequestPayload {
    formType: string,
    email: string,
    phone: string,
    documents: string[] | null,
    requestDescription: string,
    firstName: string,
    lastName: string,
    bflNumber: string,
    partnerCompany: string,
    requestTopics: string[],
    legacyContractNumber: null | string,
    newContractNumber: null | string,
    desiredCompletionDate: string
}
