export interface PartnerServiceRequestStepYourData {
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    bflNumber: string,
    partnerCompany: null | string
}
