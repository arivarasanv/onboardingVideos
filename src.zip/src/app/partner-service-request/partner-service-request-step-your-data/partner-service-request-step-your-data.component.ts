import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, FormGroupDirective, Validators} from '@angular/forms';
import {FormGroupConfig} from 'src/app/helpers/form-group-config';
import {PartnerServiceRequestStepYourData} from './partner-service-request-step-your-data';

@Component({
  selector: 'app-partner-service-request-step-your-data',
  templateUrl: './partner-service-request-step-your-data.component.html',
  styleUrls: ['./partner-service-request-step-your-data.component.scss']
})
export class PartnerServiceRequestStepYourDataComponent implements OnInit {
  public _parent: FormGroup;
  @Input() displayQuestions: boolean;

  constructor(private rootFormGroup: FormGroupDirective) {

  }

  ngOnInit(): void {
    this._parent = this.rootFormGroup.control;
  }

  getConfig() {
    const config: FormGroupConfig<PartnerServiceRequestStepYourData> = {
      firstName: ['', [Validators.required, Validators.pattern("^[A-ZÄÖÜßa-zäöü]{1}[A-ZÄÖÜßa-zäöü #&_/\\-]+$"), Validators.minLength(2), Validators.maxLength(45)]],
      lastName: ['', [Validators.required, Validators.pattern("^[A-ZÄÖÜßa-zäöü]{1}[A-ZÄÖÜßa-zäöü #&_/\\-]+$"), Validators.minLength(2), Validators.maxLength(45)]],
      email: ['', [Validators.required, Validators.maxLength(80), Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      phone: ['', [Validators.required, Validators.pattern("^[0-9\-\+]{9,20}$")]],
      bflNumber: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      partnerCompany: [null, [Validators.pattern("^[A-ZÄÖÜßa-zäöü]{1}[A-ZÄÖÜßa-zäöü #&_/\\-]+$"), Validators.minLength(3), Validators.maxLength(80)]]
    }

    return config;
  }

  showWarningSign(fieldname: string){
    return (this.fieldPattern(fieldname)) || (this.fieldMinLength(fieldname) || this.fieldMaxLength(fieldname)) || this.fieldRequired(fieldname);
  }

  fieldInvalid(fieldname: string) {
    return this._parent.get('stepYourData')!.get(fieldname)?.invalid && this._parent.get('stepYourData')!.get(fieldname)?.touched;
  }

  fieldRequired(fieldname: string) {
    return this._parent.get('stepYourData')!.get(fieldname)?.errors?.required && this._parent.get('stepYourData')!.get(fieldname)?.touched;
  }

  fieldPattern(fieldname: string) {
    return this._parent.get('stepYourData')!.get(fieldname)?.errors?.pattern && this._parent.get('stepYourData')!.get(fieldname)?.touched;
  }

  fieldMinLength(fieldname: string) {
    return this._parent.get('stepYourData')!.get(fieldname)?.errors?.minlength && this._parent.get('stepYourData')!.get(fieldname)?.touched;
  }

  fieldMaxLength(fieldname: string) {
    return this._parent.get('stepYourData')!.get(fieldname)?.errors?.maxlength && this._parent.get('stepYourData')!.get(fieldname)?.touched;
  }

  fieldEmail() {
    return this._parent.get('stepYourData.email')!.errors?.email && this._parent.get('stepYourData.email')!.touched;
  }

}
