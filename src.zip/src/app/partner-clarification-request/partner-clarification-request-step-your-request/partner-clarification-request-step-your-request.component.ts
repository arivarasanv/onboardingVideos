import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { FormGroupConfig } from 'src/app/helpers/form-group-config';
import { PartnerServiceRequestComponent } from 'src/app/partner-service-request/partner-service-request.component';
import { PartnerClarificationRequestStepYourRequest } from './partner-clarification-request-step-your-request';

@Component({
  selector: 'app-partner-clarification-request-step-your-request',
  templateUrl: './partner-clarification-request-step-your-request.component.html',
  styleUrls: ['./partner-clarification-request-step-your-request.component.scss']
})
export class PartnerClarificationRequestStepYourRequestComponent implements OnInit {
  public _parent: FormGroup;
  @Input() displayQuestions: boolean;
  @Input() guid: string;

  //TODO: refactor the two props below and associated logic into dropzone.component
  public unsupportedFiles: string[];
  public supportedFileExtensions: string[];


  //TODECIDE: is it overengineering to emit the boolean state of min/max files from the dropzone component. Should it be handled here?
  public MINIMUM_DROPZONE_FILE_COUNT: number = 1;
  public MAXIMUM_DROPZONE_FILE_COUNT: number = 5;

  public maxFileCountReached: boolean;
  public minFileCountNotReached: boolean;

  public documentsNotUploaded: boolean;

  constructor(private rootFormGroup: FormGroupDirective) { }

  ngOnInit(): void {
    this._parent = this.rootFormGroup.control;
    this._parent.valueChanges.subscribe(() => {
      if(this._parent.controls.stepYourRequest.value.documents.length <= 0)
        this._parent.controls.stepYourRequest.get('documents')?.setErrors({'incorrect': true});
      else
        this._parent.controls.stepYourRequest.get('documents')?.setErrors(null);
    })
  }

  getConfig() {
    const config: FormGroupConfig<PartnerClarificationRequestStepYourRequest> = {
      requestDescription: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(250)]],
      documents: [[], [Validators.minLength(1), Validators.maxLength(5)]],
      dunningAmount: ['', []],
      appointmentDate: ['', []],
      appointmentTime: ['', []]
    }

    return config;
  }

  handleDatePickerInputClicked(inputClicked: boolean) {
    if(inputClicked)
      this._parent.get('stepYourRequest')!.get("desiredCompletionDate")?.markAsTouched();
  }

  handleDocumentsNotUploaded(status: boolean) {
    this.documentsNotUploaded = status; 
  }

  handleFileCountMaximumReached(status: boolean) {
    this.maxFileCountReached = status;
  }
  handleFileCountMinimumNotReached(status: boolean) {
    this.minFileCountNotReached = status;
  }

  syncDateWithParent(selectedDate: string){
    this._parent.controls.stepYourRequest.patchValue({"appointmentDate": selectedDate});
  }

  syncTimeWithParent(selectedTime: string){
    this._parent.controls.stepYourRequest.patchValue({"appointmentTime": selectedTime});
  }

  handleUnsupportedFileTypes(extensions: string[][]) {
    //TODECIDE: is it wise to emit supported extensions as 2nd dimension of event array?
    this.unsupportedFiles = extensions[0];
    this.supportedFileExtensions = extensions[1];
  }

  updateDropzoneControlState() {
    this._parent.get('stepYourRequest.documents')?.markAsTouched();
  }

  addDocumentIdToRequest(id: string) {
    let arr = this._parent.value.stepYourRequest.documents;
    arr.push(id);
    this._parent.controls.stepYourRequest.patchValue({"documents": arr})  
  }

  removeDocumentIdFromRequest(id: string) {
    let index = this._parent.value.stepYourRequest.documents.indexOf(id);
    this._parent.value.stepYourRequest.documents.splice(index, 1);
    let arr = this._parent.value.stepYourRequest.documents;
    this._parent.controls.stepYourRequest.patchValue({"documents": arr});
  }

  documentsRequired() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount < 1;
    }
    return false;
  }

  documentsMax() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount > 1;
    }
    return false;
  }

  fileTypesUnsupported() {
    return this.unsupportedFiles != null;
  }

  fieldInvalid(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.invalid && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldRequired(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.required && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldPattern(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.pattern && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMinLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.minlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMaxLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.maxlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldEmail() {
    return this._parent.get('stepYourRequest.email')!.errors?.email && this._parent.get('stepYourRequest.email')!.touched;
  }

}
