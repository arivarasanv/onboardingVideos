export interface PartnerClarificationRequestStepYourRequest {
    requestDescription: string,
    documents: string[],
    dunningAmount: string,
    appointmentDate: string,
    appointmentTime: string
}