import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HelperFunctions } from '../helpers/helper-functions';
import { DropzoneDocumentStorageService } from '../services/dropzone-document-storage.service';
import { ServiceRequestService } from '../services/service-request.service';
import { PartnerClarificationRequestPayload } from './partner-clarification-request';
import { PartnerClarificationRequestStepYourDataComponent } from './partner-clarification-request-step-your-data/partner-clarification-request-step-your-data.component';
import { PartnerClarificationRequestStepYourRequestComponent } from './partner-clarification-request-step-your-request/partner-clarification-request-step-your-request.component';

@Component({
  selector: 'app-partner-clarification-request',
  templateUrl: './partner-clarification-request.component.html',
  styleUrls: ['./partner-clarification-request.component.scss']
})
export class PartnerClarificationRequestComponent implements OnInit {
  @ViewChild(PartnerClarificationRequestStepYourDataComponent, {static: true}) stepYourDataGroup: PartnerClarificationRequestStepYourDataComponent;
  @ViewChild(PartnerClarificationRequestStepYourRequestComponent, {static: true}) stepYourRequestGroup: PartnerClarificationRequestStepYourRequestComponent;

  partnerClarificationRequest: FormGroup;
  stepYourData: FormGroup;
  stepYourRequest: FormGroup;
  firstPage: boolean = true;
  secondPage: boolean;
  submitFailed: boolean;
  isAppFinishedPopup = false;
  sendButtonClicked: boolean;
  requestGuid: string;

  constructor(private fb: FormBuilder,
    private serviceRequestService: ServiceRequestService,
    private dropzoneDocumentStorageService: DropzoneDocumentStorageService) { }

  ngOnInit(): void {
    this.stepYourData = this.fb.group(this.stepYourDataGroup.getConfig());
    this.stepYourRequest = this.fb.group(this.stepYourRequestGroup.getConfig());

    this.partnerClarificationRequest = this.fb.group({
      stepYourData: this.stepYourData,
      stepYourRequest: this.stepYourRequest
    })

    this.dropzoneDocumentStorageService.files = [];

    this.requestGuid = HelperFunctions.generateUUIDUsingMathRandom();
  }

  switchPages() {
    if (this.firstPage) {
      this.stepYourData.markAllAsTouched();
      if (this.stepYourData.invalid) {
        return;
      }
    }

    this.firstPage = !this.firstPage;
    this.secondPage = !this.secondPage;
  }
  
  //TODO: Refactor into component usable by CSR and PCR both. best if resuable for all forms and extendable for specific cases
  submitRequest() {
    this.sendButtonClicked = true;
    if (this.secondPage) {
      this.stepYourRequest.markAllAsTouched();
      if (this.stepYourRequest.invalid) {
        this.sendButtonClicked = false;
        return;
      }
    }

    let stepYourData = this.partnerClarificationRequest.value.stepYourData;
    let stepYourRequest = this.partnerClarificationRequest.value.stepYourRequest;
    let combined = Object.assign(stepYourData, stepYourRequest);

    let payload: PartnerClarificationRequestPayload = {
      formType: "PARTNER_CLARIFICATION_REQUEST",
      email: combined.email,
      phone: combined.phone,
      documents: combined.documents,
      requestDescription: combined.requestDescription,
      firstName: combined.firstName,
      lastName: combined.lastName,
      bflNumber: null,
      partnerCompany: combined.partnerCompany,
      partnerNumber: combined.partnerNumber,
      dunningAmount: combined.dunningAmount,
      appointmentDate: null,
      appointmentTime: null
    }

    payload.appointmentDate = formatDate();
    payload.appointmentTime = formatTime();

    if(combined.bflNumber != undefined && combined.bflNumber != ""){
      payload.bflNumber = combined.bflNumber;
    }


    this.serviceRequestService.submitRequest(payload, this.requestGuid).subscribe(
      {
        next: () => {this.submitFailed = false; this.isAppFinishedPopup = true;},
        error: () => {this.submitFailed = true; this.sendButtonClicked = false;}
      });


    //TODO: solve this via DatePipe
    //TODO: utilize the formatDate and formatTime functions in a smarter manner
    function formatDate() {
      function addLeadingZeros(n: any) {
        if (n <= 9) {
          return "0" + n;
        }
        return n;
      }

      if(combined.appointmentDate != undefined){
        let currentDate = new Date(combined.appointmentDate);
        let formattedDate = currentDate.getFullYear() + "-" +
        addLeadingZeros(currentDate.getMonth() + 1) +
        "-" + addLeadingZeros(currentDate.getDate());
        
        return formattedDate;
      }
      
      return null;
    }
    
    
    function formatTime() {
      if(combined.appointmentTime != undefined){
        let currentTime = combined.appointmentTime;
        return currentTime;
      }
      return null;
    }
  }

  onFinishPopupClose() {
    HelperFunctions.redirectToExternalHomeUrl();
  }
}
