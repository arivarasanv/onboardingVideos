export interface PartnerClarificationRequestPayload {
    formType: string,
    email: string,
    phone: string,
    documents: string[],
    requestDescription: string,
    firstName: string,
    lastName: string,
    bflNumber: string | null,
    dunningAmount: string,
    partnerCompany: string,
    partnerNumber: string,
    appointmentDate: string | null,
    appointmentTime: string | null
}