export interface PartnerClarificationRequestStepYourData {
    partnerCompany: string,
    partnerNumber: string,
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    bflNumber: string | null,
}