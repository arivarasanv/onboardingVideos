export interface CustomerServiceRequestStepYourRequest {
    requestDescription: string,
    documents: string[],
    appointmentDate: string,
    appointmentTime: string
}