export interface CustomerServiceRequestPayload {
    formType: string,
    email: string,
    phone: string,
    documents: string[],
    requestDescription: string,
    firstName: string,
    lastName: string,
    bflNumber: string | null,
    customerCompany: string,
    customerNumber: string,
    appointmentDate: string | null,
    appointmentTime: string | null
}