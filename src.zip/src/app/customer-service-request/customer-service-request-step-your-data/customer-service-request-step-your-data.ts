export interface CustomerServiceRequestStepYourData {
    customerCompany: string,
    customerNumber: string,
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    bflNumber: string | null,
}