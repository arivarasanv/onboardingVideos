import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, FormGroupDirective, Validators} from '@angular/forms';
import {FormGroupConfig} from 'src/app/helpers/form-group-config';
import {GeneralServiceRequestStepYourRequest} from './general-service-request-step-your-request';

@Component({
  selector: 'app-general-service-request-step-your-request',
  templateUrl: './general-service-request-step-your-request.component.html',
  styleUrls: ['./general-service-request-step-your-request.component.scss']
})
export class GeneralServiceRequestStepYourRequestComponent implements OnInit {
  public _parent: FormGroup;
  @Input() displayQuestions: boolean;
  @Input() guid: string;

  //TODO: refactor the two props below and associated logic into dropzone.component
  public unsupportedFiles: string[];
  public supportedFileExtensions: string[];

  public MINIMUM_DROPZONE_FILE_COUNT: number = 1;
  public MAXIMUM_DROPZONE_FILE_COUNT: number = 1;

  public maxFileCountReached: boolean;
  public minFileCountNotReached: boolean;

  public documentsNotUploaded: boolean;

  public clr_position: string = "top-middle";
  private clrPositionWidthBreakpoint: number = 1070

  constructor(private rootFormGroup: FormGroupDirective) {
  }

  ngOnInit(): void {
    //TODO: split into three separate methods
    //Method1
    this._parent = this.rootFormGroup.control;
    //Method2
    this._parent.valueChanges.subscribe(() => {
      if(this._parent.controls.stepYourRequest.value.documents.length <= 0)
        this._parent.controls.stepYourRequest.get('documents')?.setErrors({'incorrect': true});
      else
        this._parent.controls.stepYourRequest.get('documents')?.setErrors(null);
    })
    //Method3
    if(window.innerWidth < this.clrPositionWidthBreakpoint){
      this.clr_position = "top-left"
    }
  }

  getConfig() {
    const config: FormGroupConfig<GeneralServiceRequestStepYourRequest> = {
      contractActivation: [false, []],
      transfer: [false, []],
      renewal: [false, []],
      termination: [false, []],
      partialFee: [false, []],
      masterDataChange: [false, []],
      requestForCopies: [false, []],
      paymentChange: [false, []],
      terminationOfContract: [false, []],
      transferFee: [false, []],
      requestDescription: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(250)]],
      desiredCompletionDate: ['', [Validators.required]],
      documents: [[], []]
    }

    return config;
  }

  handleDatePickerInputClicked(inputClicked: boolean) {
    if(inputClicked)
      this._parent.get('stepYourRequest')!.get("desiredCompletionDate")?.markAsTouched();
  }

  handleDocumentsNotUploaded(status: boolean) {
    this.documentsNotUploaded = status; 
  }

  handleFileCountMaximumReached(status: boolean) {
    this.maxFileCountReached = status;
  }
  handleFileCountMinimumNotReached(status: boolean) {
    this.minFileCountNotReached = status;
  }

  addDocumentIdToRequest(id: string) {
    let arr = this._parent.value.stepYourRequest.documents;
    arr.push(id);
    this._parent.controls.stepYourRequest.patchValue({"documents": arr})  
  }

  removeDocumentIdFromRequest(id: string) {
    let index = this._parent.value.stepYourRequest.documents.indexOf(id);
    this._parent.value.stepYourRequest.documents.splice(index, 1);
    let arr = this._parent.value.stepYourRequest.documents;
    this._parent.controls.stepYourRequest.patchValue({"documents": arr});
  }
  //TODO: find cleaner way to do this check.
  requestTopicsInvalid() {
    if (this._parent.get('stepYourRequest.contractActivation')?.touched ||
      this._parent.get('stepYourRequest.transfer')?.touched ||
      this._parent.get('stepYourRequest.renewal')?.touched ||
      this._parent.get('stepYourRequest.termination')?.touched ||
      this._parent.get('stepYourRequest.masterDataChange')?.touched ||
      this._parent.get('stepYourRequest.requestForCopies')?.touched ||
      this._parent.get('stepYourRequest.paymentChange')?.touched ||
      this._parent.get('stepYourRequest.terminationOfContract')?.touched ||
      this._parent.get('stepYourRequest.transferFee')?.touched) {

      return this._parent.get('stepYourRequest.contractActivation')?.value == false &&
        this._parent.get('stepYourRequest.transfer')?.value == false &&
        this._parent.get('stepYourRequest.renewal')?.value == false &&
        this._parent.get('stepYourRequest.termination')?.value == false &&
        this._parent.get('stepYourRequest.masterDataChange')?.value == false &&
        this._parent.get('stepYourRequest.requestForCopies')?.value == false &&
        this._parent.get('stepYourRequest.paymentChange')?.value == false &&
        this._parent.get('stepYourRequest.terminationOfContract')?.value == false &&
        this._parent.get('stepYourRequest.transferFee')?.value == false;
    }
    return false;
  }

  syncDateWithParent(selectedDate: string){
    this._parent.controls.stepYourRequest.patchValue({"desiredCompletionDate": selectedDate});
  }

  documentsRequired() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount < 1;
    }
    return false;
  }

  documentsMax() {
    if (this._parent.get('stepYourRequest.documents')?.touched) {
      let documentCount = this._parent.get('stepYourRequest.documents')?.value?.length;
      return documentCount > 1;
    }
    return false;
  }

  fileTypesUnsupported() {
    return this.unsupportedFiles != null;
  }

  handleUnsupportedFileTypes(extensions: string[][]) {
    //TODECIDE: is it wise to emit supported extensions as 2nd dimension of event array?
    this.unsupportedFiles = extensions[0];
    this.supportedFileExtensions = extensions[1];
  }

  //TODO: why is it being triggered twice though?
  updateDropzoneControlState() {
    this._parent.get('stepYourRequest.documents')?.markAsTouched();
  }

  fieldInvalid(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.invalid && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldRequired(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.required && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldPattern(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.pattern && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMinLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.minlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldMaxLength(fieldname: string) {
    return this._parent.get('stepYourRequest')!.get(fieldname)?.errors?.maxlength && this._parent.get('stepYourRequest')!.get(fieldname)?.touched;
  }

  fieldEmail() {
    return this._parent.get('stepYourRequest.email')!.errors?.email && this._parent.get('stepYourRequest.email')!.touched;
  }

}
