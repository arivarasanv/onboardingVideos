export interface GeneralServiceRequestStepYourRequest {
    contractActivation: boolean,
    transfer: boolean,
    renewal: boolean,
    termination: boolean,
    partialFee: boolean,
    masterDataChange: boolean,
    requestForCopies: boolean,
    paymentChange: boolean,
    terminationOfContract: boolean,
    transferFee: boolean,
    requestDescription: string,
    desiredCompletionDate: string,
    documents: string[]
}
