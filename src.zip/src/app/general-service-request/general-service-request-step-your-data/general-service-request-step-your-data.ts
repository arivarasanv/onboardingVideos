export interface GeneralServiceRequestStepYourData {
  firstName: string,
  lastName: string,
  email: string,
  phone: string,
  customerName: string | null,
  bflNumber: string
}
