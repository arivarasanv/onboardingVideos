export interface GeneralServiceRequestPayload {
  formType: string,
  email: string,
  phone: string,
  documents: string[],
  requestDescription: string,
  firstName: string,
  lastName: string,
  bflNumber: string,
  customerName: string | null,
  requestTopics: string[],
  desiredCompletionDate: string
}
