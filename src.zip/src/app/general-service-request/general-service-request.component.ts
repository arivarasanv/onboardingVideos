import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { HelperFunctions } from '../helpers/helper-functions';
import { DropzoneDocumentStorageService } from '../services/dropzone-document-storage.service';
import {ServiceRequestService} from '../services/service-request.service';
import {GeneralServiceRequestPayload} from './general-service-request';
import {
  GeneralServiceRequestStepYourDataComponent
} from './general-service-request-step-your-data/general-service-request-step-your-data.component';
import {
  GeneralServiceRequestStepYourRequestComponent
} from './general-service-request-step-your-request/general-service-request-step-your-request.component';

@Component({
  selector: 'app-general-service-request',
  templateUrl: './general-service-request.component.html',
  styleUrls: ['./general-service-request.component.scss']
})
export class GeneralServiceRequestComponent implements OnInit {

  @ViewChild(GeneralServiceRequestStepYourDataComponent, {static: true}) stepYourDataGroup: GeneralServiceRequestStepYourDataComponent;
  @ViewChild(GeneralServiceRequestStepYourRequestComponent, {static: true}) stepYourRequestGroup: GeneralServiceRequestStepYourRequestComponent;


  generalServiceRequest: FormGroup;
  stepYourData: FormGroup;
  stepYourRequest: FormGroup;
  firstPage: boolean = true;
  secondPage: boolean;
  isAppFinishedPopup = false;
  submitFailed: boolean;
  sendButtonClicked: boolean;
  requestGuid: string;

  constructor(private fb: FormBuilder,
              private serviceRequestService: ServiceRequestService,
              private dropzoneDocumentStorageService: DropzoneDocumentStorageService) {
    this.firstPage = true;
  }

  ngOnInit(): void {
    this.stepYourData = this.fb.group(this.stepYourDataGroup.getConfig());
    this.stepYourRequest = this.fb.group(this.stepYourRequestGroup.getConfig());

    this.generalServiceRequest = this.fb.group({
      stepYourData: this.stepYourData,
      stepYourRequest: this.stepYourRequest
    })

    this.dropzoneDocumentStorageService.files = [];

    this.requestGuid = HelperFunctions.generateUUIDUsingMathRandom();
  }

  switchPages() {
    if (this.firstPage) {
      this.stepYourData.markAllAsTouched();
      if (this.stepYourData.invalid) {
        return;
      }
    }

    this.firstPage = !this.firstPage;
    this.secondPage = !this.secondPage;
  }

  //TODO: clean this up
  submitRequest() {
    this.sendButtonClicked = true;
    this.stepYourRequest.markAllAsTouched();
    if (this.stepYourRequest.invalid || this.stepYourRequestGroup.documentsMax() || this.stepYourRequestGroup.documentsRequired() || this.stepYourRequestGroup.requestTopicsInvalid()) {
      this.sendButtonClicked = false;
      return;
    }

    let stepYourData = this.generalServiceRequest.value.stepYourData;
    let stepYourRequest = this.generalServiceRequest.value.stepYourRequest;
    let combined = Object.assign(stepYourData, stepYourRequest);

    let payload: GeneralServiceRequestPayload = {
      formType: "GENERAL_SERVICE_REQUEST",
      email: combined.email,
      phone: combined.phone,
      documents: combined.documents,
      requestDescription: combined.requestDescription,
      firstName: combined.firstName,
      lastName: combined.lastName,
      bflNumber: combined.bflNumber,
      customerName: null,
      requestTopics: [],
      desiredCompletionDate: formatDate()
    }

    if(combined.customerName != undefined && combined.customerName != ""){
      payload.customerName = combined.customerName;
    }

    addRequestTopics();


    this.serviceRequestService.submitRequest(payload, this.requestGuid).subscribe(
      {
        next: () => {this.submitFailed = false; this.isAppFinishedPopup = true},
        error: () => {this.submitFailed = true; this.sendButtonClicked = false;}
      });

    function formatDate() {
      function addLeadingZeros(n: any) {
        if (n <= 9) {
          return "0" + n;
        }
        return n;
      }

      let currentDatetime = new Date(combined.desiredCompletionDate);

      return currentDatetime.getFullYear() + "-" +
        addLeadingZeros(currentDatetime.getMonth() + 1) +
        "-" + addLeadingZeros(currentDatetime.getDate());
    }

    function addRequestTopics() {
      if (stepYourRequest.contractActivation)
        payload.requestTopics.push("CONTRACT_ACTIVATION");
      if (stepYourRequest.transfer)
        payload.requestTopics.push("TRANSFER");
      if (stepYourRequest.renewal)
        payload.requestTopics.push("RENEWAL");
      if (stepYourRequest.termination)
        payload.requestTopics.push("TERMINATION");
      if (stepYourRequest.masterDataChange)
        payload.requestTopics.push("MASTER_DATA_CHANGE");
      if (stepYourRequest.requestForCopies)
        payload.requestTopics.push("REQUEST_FOR_COPIES");
      if (stepYourRequest.paymentChange)
        payload.requestTopics.push("PAYMENT_CHANGE");
      if (stepYourRequest.terminationOfContract)
        payload.requestTopics.push("TERMINATION_OF_CONTRACT");
      if (stepYourRequest.transferFee)
        payload.requestTopics.push("TRANSFER_FEE");
    }

  }

  onFinishPopupClose() {
    HelperFunctions.redirectToExternalHomeUrl();
  }
}
